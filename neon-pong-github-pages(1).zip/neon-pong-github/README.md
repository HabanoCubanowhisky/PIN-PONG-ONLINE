# NEON PONG ONLINE

Juego 1 vs 1 preparado para GitHub Pages.

## Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub, por ejemplo `neon-pong-online`.
2. Sube `index.html` a la raiz del repositorio.
3. Abre **Settings > Pages**.
4. En **Build and deployment**, elige **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda. GitHub mostrara la URL publica del juego.

## Multijugador

- Un jugador pulsa **CREAR SALA**.
- Comparte la invitacion generada.
- El segundo jugador abre el enlace y entra automaticamente a la sala.
- No necesita cuenta ni registro dentro del juego.

## Nota de red

El juego usa PeerJS/WebRTC. La mayoria de las conexiones funcionan directamente entre jugadores. En redes muy restrictivas o con NAT simetrico, WebRTC puede requerir un servidor TURN para garantizar la conexion.
